package com.nvl.storyapp.data.server.model

import androidx.lifecycle.LiveData
import androidx.paging.PagingData
import com.nvl.storyapp.data.server.response.*
import okhttp3.MultipartBody
import okhttp3.RequestBody

interface DataSource {
    fun login(email: String, password: String): LiveData<LoginResponse>
    fun register(name: String, email: String, password: String): LiveData<RegisterResponse>
    fun getUser(): LiveData<LoginResult>
    fun deleteUser()
    fun getStories(bearer: String): LiveData<PagingData<StoryItem>>
    fun uploadFile(bearer: String, file: MultipartBody.Part, description: RequestBody):
            LiveData<AddStoryResponse>
}